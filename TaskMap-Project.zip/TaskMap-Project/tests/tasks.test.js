const tasks = require('./tasks')
test('Should test if function is listening to the add button ')