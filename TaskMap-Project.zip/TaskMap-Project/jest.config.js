module.exports = {
    testEnvironment: 'jsdom',
};