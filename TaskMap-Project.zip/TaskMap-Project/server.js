const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();
const port = 5000;

// Create a new instance of the SQLite database
const db = new sqlite3.Database('./database/db.sqlite');

// Middleware to parse the request body as JSON
app.use(express.json());

// Handle POST request to /api/register endpoint
app.post('/api/register', (req, res) => {
    const { username, password } = req.body;

    // Insert the new user into the database
    const query = 'INSERT INTO users (username, password) VALUES (?, ?)';
    db.run(query, [username, password], function (err) {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'An error occurred while registering' });
        } else {
            // Get the ID of the inserted user
            const userId = this.lastID;

            // Assuming you have a users table with id, username, and password columns
            res.json({ user: { id: userId, username } });
        }
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
