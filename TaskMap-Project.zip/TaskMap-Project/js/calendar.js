// Get the current date
const currentDate = new Date();

// Get the calendar elements
const calendarTable = document.getElementById('calendar-table');
const prevMonthBtn = document.getElementById('prev-month-btn');
const nextMonthBtn = document.getElementById('next-month-btn');
const currentMonthLabel = document.getElementById('current-month');

// Add event listener for previous month button
prevMonthBtn.addEventListener('click', showPreviousMonth);

// Add event listener for next month button
nextMonthBtn.addEventListener('click', showNextMonth);

// Render the calendar for the current month
renderCalendar(currentDate.getMonth(), currentDate.getFullYear());

// Function to render the calendar for a given month and year
function renderCalendar(month, year) {
    // Clear the previous calendar
    calendarTable.innerHTML = '';

    // Set the current month label
    currentMonthLabel.textContent = getMonthName(month) + ' ' + year;

    // Get the number of days in the month
    const daysInMonth = getDaysInMonth(month, year);

    // Get the first day of the month
    const firstDay = new Date(year, month, 1).getDay();

    // Create the calendar rows and cells
    let date = 1;
    for (let i = 0; i < 6; i++) {
        const row = document.createElement('tr');
        for (let j = 0; j < 7; j++) {
            if (i === 0 && j < firstDay) {
                // Empty cells before the first day of the month
                const cell = document.createElement('td');
                row.appendChild(cell);
            } else if (date > daysInMonth) {
                // Empty cells after the last day of the month
                break;
            } else {
                // Calendar cells with dates
                const cell = document.createElement('td');
                cell.textContent = date;
                row.appendChild(cell);
                date++;
            }
        }
        calendarTable.appendChild(row);
    }
}

// Function to show the previous month
function showPreviousMonth() {
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();

    const previousMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    const previousYear = currentMonth === 0 ? currentYear - 1 : currentYear;

    renderCalendar(previousMonth, previousYear);
}

// Function to show the next month
function showNextMonth() {
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();

    const nextMonth = currentMonth === 11 ? 0 : currentMonth + 1;
    const nextYear = currentMonth === 11 ? currentYear + 1 : currentYear;

    renderCalendar(nextMonth, nextYear);
}

// Function to get the number of days in a month
function getDaysInMonth(month, year) {
    return new Date(year, month + 1, 0).getDate();
}

// Function to get the name of a month
function getMonthName(month) {
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return months[month];
}
