module.exports = {
   
    testEnvironment: 'jest-environment-jsdom',
};
